//esta esta es la clase del mismo paquete
package ejercicio5;
//camilo

public class Empleado2 {
  public static void main(String[] args) {
      //creamos em
      Empleado1 em1 = new Empleado1();
      //asinamos valores
      em1.setNombre("camilo");
      //muestro el siguiente mensaje en la consola
      System.out.println("el nombre de el empleado es: " + em1.getNombre());
      //asinamos valores
      em1.setSalario(1500000);
      //asinamos valores
       em1.setSalario(1200000);
       //mmuestro el siguiente mensaje en la consola
      System.out.println("el salario del empleado es: " +em1.getSalario());
      //asinamos valores
     em1.aumentosalario(10);
      
  }
    
}
