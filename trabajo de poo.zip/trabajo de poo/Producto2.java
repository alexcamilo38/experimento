//esta esta es la clase del mismo paquete
package ejercicio3;
//camilo

public class Producto2 {
  public static void main(String[] args) {
      //creamos pro
      Producto1 pro1 =  new Producto1();
      //Asinamos valores
      pro1.setNombre("portatil");
      //muestro el siguiente mensaje en la consola
      System.out.println("el producto es: " + pro1.getNombre());
      //Asinamos valores
      pro1.setPrecio(2500000);
      //muestro el siguiente mensaje en la consola
      System.out.println("el precio es: " + pro1.getPrecio());
      //Asinamos valores
      pro1.setStock(20);
      //muestro el suguiente mensaje en la consola
      System.out.println("el stock es: " + pro1.getStock());
      
      //asinamsos el valor
      pro1.vender(15);
      
  }
    
}
