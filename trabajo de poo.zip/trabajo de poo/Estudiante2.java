//esta esta es la clase del mismo paquete
package ejercicio2;


public class Estudiante2 {
     public static void main(String[] args) {
         //creamos estudiante
         Estudiante1 estudiante=new Estudiante1();
         //asinamos valores validos
         estudiante.setNombres("camilo");
         //asinamos valores validos 
         estudiante.setNota(5.0);
         
         estudiante.mostrarinformacion();
         // muestro el siguiente mensaje en la consola
         System.out.println("\nInformacion del estudiante");
         System.out.println(" nombre: " +estudiante.getNombres() + " nota: " +estudiante.getNota());
     }
}
