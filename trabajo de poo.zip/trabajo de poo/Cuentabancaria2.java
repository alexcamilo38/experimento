//esta esta es la clase del mismo paquete
package ejercicio1;


public class Cuentabancaria2 {
     
    
    public static void main(String[] args) {
        //creamos un cuenta
        Cuentabancaria1 cuenta1= new Cuentabancaria1();
        Cuentabancaria1 cuenta2= new Cuentabancaria1();
        cuenta1.setNumerocueta("12345");
       cuenta1.setSaldo(50000);
        cuenta2.setNumerocueta("67891");
        cuenta2.setSaldo(200000);
        
        cuenta1.depocitar(300000);
        cuenta1.retirar(1000);
        
        cuenta2.depocitar(20000);
        cuenta2.retirar(1000);
        //Muestro los  siguientes mensaje en la consola
        System.out.println("\nsaldo final ");
         System.out.println("cuenta numero 1: " +cuenta1.getNumerocueta() + " saldo final de: " +cuenta1.getSaldo());
        System.out.println("centa numro 2 : " +cuenta2.getNumerocueta() + " saldo final de: " +cuenta2.getSaldo());
        
     }
            
}
                    