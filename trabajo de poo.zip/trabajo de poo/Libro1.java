//esta es la clase libro1
package ejercicio4;

//camilo

//Atributos privados
public class Libro1 {
    private String titulo;
    private String autor;
    private int pagina;

   //metodo de acceso setter, para inicializar o establecer
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
      public String getTitulo() {
        return titulo;
    }

   
    public void setAutor(String autor) {
        this.autor = autor;
    }
     public String getAutor() {
        return autor;
    }


    public void setPagina(int pagina) {
        if(pagina>10){
          this.pagina = pagina;   
         }
        else{
            //muestro el siguiente mensaje si no se cumple con la condicion 
            System.out.println("El numero de paguinas debe ser mayor a 10");
        }
    }
    
    public int getPagina() {
        return pagina;
    }  
    
    
    
}
