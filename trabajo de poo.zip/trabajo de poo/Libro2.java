//esta esta es la clase del mismo paquete
package ejercicio4;
//camilo

public class Libro2 {
    public static void main(String[] args) {
         //creamos un objeto
        Libro1 objeto1 = new Libro1();
        Libro1 objeto2 = new Libro1();
        //asinamos valores
        objeto1.setTitulo("cien anos de soleda");
        //asinamos valores
        objeto1.setAutor("Gabriel Garcia Marquez");
        //asinamso valores
        objeto1.setPagina(417);
        //asinamsos valores
        objeto2.setTitulo("aladino");
        //Asinmos volores
        objeto2.setAutor("Antoine");
        //asinamos valores
        objeto2.setPagina(6);
        //Muestro los mesajes en la consola
        System.out.println("Libro 1: ");
        System.out.println("El titulo de el libro es: " +objeto1.getTitulo() + "\n El autor es: " +objeto1.getAutor() +  " \n El numero de paguinas es: " +objeto1.getPagina());
        System.out.println(" \nLibro 2: ");
        System.out.println("El titulo de el libro es: " +objeto2.getTitulo() + "\n El autor es: " +objeto2.getAutor()+ "\n El numero de paguinas es: " + objeto2.getPagina());
    } 
}
