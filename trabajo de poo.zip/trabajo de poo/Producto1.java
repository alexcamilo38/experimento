//esta es la clase producto1 
package ejercicio3;
//camilo


//Atributos  privados
public class Producto1 {
private String nombre;
private double precio;
private int stock;
   
//metodo de acceso setter, para inicializar o establecer
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setPrecio(double precio) {
       if(precio >=100){
           this.precio = precio;
       } 
       else{
           //muestro el siguiente mensaje en consola si no cumple con las condiciones
           System.out.println(" Error el precio no puede ser menor a 100");
       }
    }
    
     public double getPrecio() {
        return precio;
    }


    public void setStock(int stock) {
      if(stock >=0){
          this.stock = stock; 
      }  
      else{
          //muestro si siguiente mensaje en consola si no cumple con las condiones 
          System.out.println(" Error el stock no puede ser negativo");
      }
    }
     
      public int getStock() {
        
        return stock;
    }
     public void vender(int cantidad){
         if(cantidad > 0 && cantidad <= stock){
             stock -= cantidad;
             //muestro el siguiente mesaje en la consola
             System.out.println("Se vendieron " +cantidad+  " unidades stock para vender " + stock);
         }
         else{
             //muestro el siguiente mensaje el la consola
             System.out.println("No hay suficientes stock para vender " + cantidad + " unidades");
         }
     }
     
}
