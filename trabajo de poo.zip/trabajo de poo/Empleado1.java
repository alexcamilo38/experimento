//esta es la clase empleado1
package ejercicio5;
//camilo


public class Empleado1 {
    //Atributos privados
     private String nombre;
  private double salario;

//metodo de acceso setter, para inicializar o establecer
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }

    public void setSalario(double salario) {
        if(salario>=1300000){
        this.salario = salario;
    }
        else {
            //muestro el siguiente mensaje en la consola si no se cumple con las condiciones
            System.out.println("el salario no puede ser menor a minimo (1300000)");
        } 
    }
    
    public double getSalario() {
        return salario;
    }
    public void aumentosalario(double porcentaje) {
        if(porcentaje>0){
            double aumento= salario* porcentaje /100;
            salario+=aumento; 
            //estro el siguiente mensaje en la consola
            System.out.println("El salario ha sido imcrementado en un " +porcentaje + " % nuevo salario: " +salario);
    }
        else{
            //muestro el siguiente mensaje en la consola
            System.out.println("el porcentaje tiene que ser mayor que 0");
        }
   }
}