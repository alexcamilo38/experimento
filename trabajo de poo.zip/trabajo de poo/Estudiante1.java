//Esta es la clase estudiante1
package ejercicio2;


public class Estudiante1 {
 //Atributos privados
    private String nombres;
    private double nota;
//metodo de acceso setter, para inicializar o establecer
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

     public String getNombres() {
        return nombres;
    }
  

    public void setNota(double nota) {
       if(nota>=0 && nota<=5){
            this.nota = nota;
       }
       else{
           // se muestra el siguiente mensaje si no cumple con las condiciones
           System.out.println("Error la nota debe estar entre 0 y 5");
       }
     
    }
     public double getNota() {
        return nota;
    }
    public void mostrarinformacion(){
        System.out.println("nombre: "+nombres + "\n nota: " +nota);
    }
}
