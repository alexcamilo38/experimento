//esta en ejercicio1
package ejercicio1;

//by camilo


public class Cuentabancaria1 {
    //Atributos Privados
    private String numerocueta;
    private double saldo;

   //metodo de acceso setter, para inicializar o establecer
    public void setNumerocueta(String numerocueta) {
        this.numerocueta = numerocueta;
    }
    
    public String getNumerocueta() {
        return numerocueta;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getSaldo() {
        return saldo;
    }
    public void depocitar(double monto){
        if(monto>0){
            saldo+=monto;
        }
    }
    public void retirar(double monto){
        if(monto>0 && monto<= saldo){
            saldo-=monto;
        }
    }
}
